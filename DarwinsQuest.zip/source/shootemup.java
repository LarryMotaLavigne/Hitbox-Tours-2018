import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class shootemup extends PApplet {








// Game Parameters
boolean pause = false;
boolean[] touches = new boolean[5];
int ennemisGeneres = 0, moche = 0, vitesse = 5, IDCitation;
String[] citations;

// Image & Font Management
PFont police;
PImage[] guillemets = new PImage[2];
//PFont fonteContours, fonteRemplissage;

// Character Management
Boss calmar;
Boss owen;
Decor decor;
Joueur joueur;
ArrayList<Ennemi> ennemis = new ArrayList<Ennemi>();
boolean isOwenDead = false;
boolean isCalmarDead = false;
boolean isFirstWaveDead = false;
long firstWaveMilli = 0;
boolean isSecondWaveDead = false;
long secondWaveMilli = 0;
int waveTime = 15; // in seconds

// Scene Management
enum Scene {
  Menu, Game, GameOver, Intro, Win
}
Scene state=Scene.Menu;

// Music Management
Minim minim;
SoundMaster soundMaster;

/******************************************************************************************/
/*                                       GAME INIT                                        */
/******************************************************************************************/
public void setup()
{
  surface.setTitle("Darwin's Quest: A Bad Owen");
  //surface.setLocation(200,200);
  
  frameRate(30);
  
  noStroke();
  noFill();
  citations = loadStrings("citations.txt");
  for (int i = 0; i < citations.length; i++)
  {
    citations[i] = citations[i].replaceAll("§", "\n");
  }
  IDCitation = PApplet.parseInt(random(0, citations.length));
  //colorMode(HSB);
  police = createFont("Velvet Heart Font.ttf", 128);
  textSize(48);
  textFont(police);
  guillemets[0] = loadImage("guillemets0.png");
  guillemets[1] = loadImage("guillemets1.png");
  //fonteContours = createFont("data/WIDEAWAKE.TTF", 128);
  //fonteRemplissage = createFont("data/WIDEAWAKEBLACK.ttf", 128);

  // Musiques et Sons
  minim = new Minim(this);
  soundMaster = new SoundMaster(minim);


  joueur = new Joueur(soundMaster);
  decor = new Decor();
}

/******************************************************************************************/
/*                                  DRAWING FUNCTIONS                                     */
/******************************************************************************************/

// Main Loop
public void draw()
{
  switch(state) {
  case Menu:
    drawMenu();
    break;
  case Game:
    drawGame();
    break;
  case Intro:
    drawIntro();
    break;
  case GameOver:
    drawGameOver();
    break;
  case Win:
    drawWin();
    break;
  }
}

public void drawMenu()
{
  background(255);
  // Music de l'intro
  soundMaster.playIntro();
  text(mouseX+"    "+mouseY, mouseX, mouseY);
  decor.afficherFond();
  fill(255, 255, 255);
  rect(width/2 - 60, height/2 - 85, 120, 30, 3);
  fill(255, 255, 255);
  rect(width/2 - 60, height/2 + 15, 120, 30, 3);
  textAlign(CENTER);
  textSize(128);
  text("Darwin's Quest", width/2, 150);
  textSize(80);
  text("A Bad Owen", width/2, 200);
  textSize(48);
  fill(0, 0, 0);
  text("Start", width/2, 300);
  text("Exit", width/2, 400);
  rectMode(CENTER);
  stroke(0);
  fill(255, 200);
  rect(width/2, height-140, 600, 140, 3);
  image(guillemets[0], width/2-300, height-208, 57, 45);
  image(guillemets[1], width/2+300-58, height-70-47, 57, 45);
  fill(0);
  noStroke();
  textAlign(CENTER, CENTER);
  textLeading(40);
  text(citations[IDCitation], width/2, height-150);
  rectMode(CORNER);
  decor.afficherFiligranes();
}

public void drawWin()
{
  // Music de l'intro
  soundMaster.playIntro();

  decor.afficherFond();
  textAlign(CENTER);
  textSize(128);
  text("Darwin's Quest", width/2, 350);
  textSize(80);
  text("A Bad Owen", width/2, 400);
  textSize(68);
  text("Félicitations !\nVous avez finis la démo de :", width/2, 200);
  textSize(38);
  text("Réalisation : Valentine, Clément, Florian et Larry.", width/2, 680);
  textSize(28);
  text("Avec le soutien de David Goodenough", width/2, 710);
  textSize(48);
  rectMode(CENTER);
  stroke(0);
  fill(255, 200);
  rect(width/2, height-140, 600, 140, 3);
  fill(0);
  noStroke();
  textAlign(CENTER, CENTER);
  textLeading(40);
  text(citations[IDCitation], width/2, height-150);
  rectMode(CORNER);
  decor.afficherFiligranes();
}


public void drawIntro()
{
  soundMaster.playIntro();
  decor.afficherFond();
  textAlign(CENTER);
  textSize(48);
  rectMode(CENTER);
  stroke(0);
  fill(255, 200);
  rect(width/2, height-340, 600, 800, 3);
  fill(0);
  noStroke();
  textAlign(CENTER, CENTER);
  textLeading(40);
  text("Charles Darwin a découvert que l’Homme avait \n un ancêtre en commun avec les primates!\n\n Tellement content de sa découverte\n il décide de publier un livre de cette théorie.\n Il en parle à son rival\n 'Sir Richard Owen'\n qui n’est pas d’accord avec lui.\n Ce dernier décide de prendre les notes\n de sa découverte afin de l'empêcher\n de publier son fameux livre :\n 'L'origine des espèces'", width/2, height-370);
  rectMode(CORNER);
  text("Appuyez sur 'Espace' pour aider Darwin !", width/2, height-60);
  PImage darwin = loadImage("darwin.png");
  image(darwin, -140, -30);
  text("Charles Darwin", 170, 600);
  PImage owen = loadImage("owen.png");
  image(owen, 800, 200);
  text("Richard Owen", 1080, 200);
  text("Utilise les flèches pour Bouger !", 1111, 20);
  text("Et la barre Espace pour Tirer !", 1111, 60);
  decor.afficherFiligranes();
}


public void drawGame()
{
  if (focused && !pause)
  {
    decor.afficherFond();
    joueur.afficher();
    wave();
    joueur.action(touches);
    decor.afficherFiligranes();
  } else if (moche++ == 0)
  {
    for (int i = 0; i < touches.length; i++) touches[i] = false;
    text("Pause", width/2, height/2-36, 72);
    //text("Quitter", width/2, height/2+24, 48);
  }
}


public void drawGameOver()
{
  background(255);
  pushMatrix();
  translate(0, random(8)-4);
  decor.afficherFond();
  fill(255, 255, 255);
  rect(width/2 - 60, height/2 - 85, 120, 30, 3);
  fill(255, 255, 255);
  rect(width/2 - 60, height/2 + 15, 120, 30, 3);
  textAlign(CENTER);
  textSize(80);
  text("GAME OVER", width/2, 150);
  textSize(48);
  fill(0, 0, 0);
  textAlign(CENTER);
  text("Retry", width/2, 300);
  textAlign(CENTER);
  text("Menu", width/2, 400);
  decor.afficherFiligranes();
  popMatrix();
}

/******************************************************************************************/
/*                                       UTILITIES                                        */
/******************************************************************************************/

public void wave()
{
  if(!isFirstWaveDead)
  {
    // Music du niveau
    soundMaster.playLevelMusic();
    
    if(firstWaveMilli==0)
    {
      firstWaveMilli = millis();
    }
    waveEnnemies(waveTime, firstWaveMilli);
  }
  else if(!isCalmarDead)
  {
    waveCalmar();
  }
  else if(!isSecondWaveDead)
  {
    if(secondWaveMilli==0)
    {
      secondWaveMilli = millis();
    }
    waveEnnemies(waveTime, secondWaveMilli); 
  }
  else if(!isOwenDead)
  {
    waveOwen();
  }
  else{
    state = Scene.Win;
    soundMaster.playIntro();
  }
}

public void waveEnnemies(int seconds, long beginTime)
{
  if(millis()-beginTime > seconds * 1000)
  {
    if(!isFirstWaveDead)
      isFirstWaveDead = true;
    else if(!isSecondWaveDead)
      isSecondWaveDead = true;
  }
  
  if (PApplet.parseInt(random(70)) == 0)
  {
    ennemis.add(new Ennemi(soundMaster));
    ennemisGeneres++;
  }
  for (int i = 0; i < ennemis.size(); i++)
  {
    if (ennemis.get(i).pos[0] < -168 || ennemis.get(i).collision())
    {
      ennemis.remove(i);
      if (joueur.vie <= 0)
      {
        state = Scene.GameOver;
        joueur.resetPlayer();
      }
    }
  }
  for (Ennemi ennemi : ennemis)
  {
    ennemi.deplacer();
    ennemi.afficher();
  }
}


public void waveCalmar()
{
  if(calmar==null){
    calmar = new Calmar(soundMaster);
  }

  if (calmar.collision())
  {
    calmar.vie--;
  }
  if (calmar.vie >= 0)
  {
    calmar.attack();
    calmar.attackCollision();
    calmar.deplacer();
    calmar.afficher();
  } 
  else
  {
    calmar.afficherDeath();
    isCalmarDead = calmar.moveDead();
  }
}

public void waveOwen()
{
  if(owen==null){
    owen = new Owen(soundMaster);
    soundMaster.playOwenMusic();
  }

  if (owen.collision())
  {
    owen.vie--;
  }
  if (owen.vie >= 0)
  {
    owen.attack();
    owen.attackCollision();
    owen.deplacer();
    owen.afficher();
  } else
  {
    owen.afficherDeath();
    isOwenDead = owen.moveDead(); 
  }
}


/******************************************************************************************/
/*                                   INPUT MANAGER                                        */
/******************************************************************************************/

public void keyPressed()
{
  if (key == 'z' || key == 'Z' || keyCode == UP    ) touches[0] = true;
  if (key == 'q' || key == 'Q' || keyCode == LEFT  ) touches[1] = true;
  if (key == 's' || key == 'S' || keyCode == DOWN  ) touches[2] = true;
  if (key == 'd' || key == 'D' || keyCode == RIGHT ) touches[3] = true;
  if (key == ' ') touches[4] = true;

  //contrôles pour tester les dégâts et soins
  if (key == '-') joueur.degat();
  if (key == '+') joueur.soin();
  if (keyCode == TAB) surface.setLocation(275, 150);
  if ((key == ' ' || keyCode == ENTER) && state==Scene.Menu) state = Scene.Intro;
  if ((key == ' ' || keyCode == ENTER) && state==Scene.Intro) state = Scene.Game;
  if ((key == ' ' || keyCode == ENTER) && state==Scene.Win) state = Scene.Menu;
  if ((key == ' ' || keyCode == ENTER) && state==Scene.GameOver) state = Scene.Game;
  if (key == ESC)
  {
    pause = !pause;
    moche = 0;
  }
  key = 0;
}

public void keyReleased()
{
  if (key == 'z' || key == 'Z' || keyCode == UP    ) touches[0] = false;
  if (key == 'q' || key == 'Q' || keyCode == LEFT  ) touches[1] = false;
  if (key == 's' || key == 'S' || keyCode == DOWN  ) touches[2] = false;
  if (key == 'd' || key == 'D' || keyCode == RIGHT ) touches[3] = false;
  if (key == ' ') touches[4] = false;
}

public void mousePressed()
{
  if (state==Scene.Menu)
  {
    if ((mouseX>=(width/2-60) && mouseX<=(width/2+60)) && (mouseY>=(height/2-85) && mouseY<=(height/2-55)))
    {
      state = Scene.Intro;
    } else if ((mouseX>=(width/2-60) && mouseX<=(width/2+60)) && (mouseY>=(height/2+15) && mouseY<=(height/2+45)))
    {
      exit();
    }
  } else if (state==Scene.GameOver)
  {
    if ((mouseX>=(width/2-60) && mouseX<=(width/2+60)) && (mouseY>=(height/2-85) && mouseY<=(height/2-55)))
    {
      state = Scene.Game;
    } else if ((mouseX>=(width/2-60) && mouseX<=(width/2+60)) && (mouseY>=(height/2+15) && mouseY<=(height/2+45)))
    {
      IDCitation = PApplet.parseInt(random(0, citations.length));
      state = Scene.Menu;
    }
  }
}
interface IGameObject
{
  public void afficher();
}

abstract class NonPlayableObject implements IGameObject
{
  public abstract boolean collision();
}

abstract class PlayableObject implements IGameObject
{
  // Parameters
  int frequenceTirs = 0;
  int vie = 3;
  int degat = 0;
  int speed = 1;
  int score;
  int[] pos;
  int[] size;
  ArrayList<Tir> tirs = new ArrayList<Tir>();
  
  public abstract void tirer();
}
class Tir
{
  int[] pos = {0, 0};
  int[] size = {20, 20};
  int speed = 2;
  
  Tir(int x, int y, int w, int h)
  {
    pos[0] = x + 90;
    pos[1] = y + 100;
    size[0] = w;
    size[1] = h;
  }
  
  Tir(int x, int y)
  {
    pos[0] = x + 90;
    pos[1] = y + 100;
  }
  
  public void deplacer()
  {
    pos[0] += 25 * speed;
  }
  
  public void moveLeft()
  {
   pos[0] -= 25 * speed; 
  }
  
  public void afficherLaser()
  {
    //stroke(4, 168, 255);
    stroke(255,0,0);
    strokeWeight(7);  
    line(pos[0], pos[1], pos[0]+size[0], pos[1]);
    stroke(255);
    strokeWeight(1);
    line(pos[0], pos[1], pos[0]+size[1], pos[1]);
  }
  
  public void afficherImage(PImage[] image)
  {
    image(image[PApplet.parseInt(frameCount/image.length)%image.length], pos[0], pos[1], size[0], size[1]);
  }

}
class Boss extends NonPlayableObject
{
  int[] pos = { width };
  int[] size = {300,300};
  PImage[] boss = new PImage[2];
  PImage deadBoss = new PImage();
  boolean goToTop=true;
  int vie;
  PImage[] attack = new PImage[5];
  ArrayList<Tir> tirs = new ArrayList<Tir>();

  // Timer pour les frames d'invulnérabilité
  int timeSinceLastHit = 0;
  int invicibilityTime = 1000;
  boolean justBeenHit = false;

  SoundMaster soundMaster;
  String deathSoundName;
  
  int timeOfDeath = 0;
  boolean isAlive = true;
  int delayForDeathAnimation = 3000;
  
  int timeSinceLastShot = 0;
  int cooldownTime = 500;
 
  Boss(SoundMaster p_soundMaster, String p_deathSoundName){
    soundMaster = p_soundMaster;
    deathSoundName = p_deathSoundName;
    
    timeSinceLastHit = millis();
  }
  
  
  
  /******************************************************************************************/
  /*                                       DISPLAY                                          */
  /******************************************************************************************/

  public void afficher()
  {
    
    if(!canBeHit() && (justBeenHit || millis() %10 == 0)){
      tint(0,0);
      justBeenHit = false;
    }
    else{
      tint(255,255,255);
    }
    
    image(boss[(frameCount/5)%2],pos[0], pos[1], size[0], size[1]);
    
    tint(255,255,255);
  }
  
  public void afficherDeath()
  {
    image(deadBoss,pos[0], pos[1], size[0], size[1]);
    soundMaster.playSoundEffect(deathSoundName);
  }
  
  public void clignoter(){
    tint(0,0);
    image(boss[(frameCount/5)%2],pos[0], pos[1], size[0], size[1]);
  }
 
  /******************************************************************************************/
  /*                                         MOVE                                           */
  /******************************************************************************************/

  public boolean moveDead()
  {
    if(isAlive){
      timeOfDeath = millis();
      isAlive = false;
      
      return false;
    }
    else{
      if(size[1] + pos[1] > 0){
        pos[1] += 5;
      }
      
      return millis() - timeOfDeath > delayForDeathAnimation;
    }
  }
  
  public void deplacer()
  {
    if(pos[0]+size[0]>width)
    {
      pos[0] -= 5;
    }
    else{ 
      // Go top
      if(goToTop)
      {
        if(pos[1]+size[1]>=height)
        {
          goToTop = !goToTop;
        }
        else
        {
          pos[1] += 5;
        }
      }
      // Go down
      else
      {
        if(pos[1]<0)
        {
          goToTop = !goToTop;
        }
        else
        {
          pos[1] -= 5;
        }
      }
    }   
  }
  
  /******************************************************************************************/
  /*                                        UTILITIES                                       */
  /******************************************************************************************/
  
  public boolean collision()
  {
    // If the boss touch the player
    if(joueur.pos[0] < pos[0]+size[0] && joueur.pos[0]+joueur.size[0] > pos[0] && joueur.pos[1] < pos[1]+size[1] && joueur.pos[1]+joueur.size[1] > pos[1])   
    {
      joueur.degat();
      return true;
    }
    
    // If the boss receive a shot      
    for (int i = 0; i < joueur.tirs.size(); i++)
    {
      if (joueur.tirs.get(i).pos[1] >= pos[1] && joueur.tirs.get(i).pos[1] < pos[1]+size[1] && joueur.tirs.get(i).pos[0] > pos[0] && joueur.tirs.get(i).pos[0]+joueur.tirs.get(i).size[0] < pos[0]+size[0])
      {
        if(canBeHit()){
          timeSinceLastHit = millis();
          justBeenHit = true;
          joueur.tirs.remove(i);        
          soundMaster.playSoundEffect("ennemyHit");
          joueur.score++;
          return true;
        }
      }
    }

    return false; 
  }
  
  public void attack()
  {
    if(canShoot()){
      if (PApplet.parseInt(random(50)) == 0)
      {
       timeSinceLastShot = millis();
       tirs.add(new Tir(pos[0], pos[1], size[0], size[1]));
      }
    }
    
    attackCollision();
    
    for (Tir tir : tirs)
    {
      tir.moveLeft();
      tir.afficherImage(attack);
    }
     
  }
  
  
  public void attackCollision()
  {
    // If the Player receive a shot
    if(tirs == null)
      return;
    for (int i = 0; i < tirs.size(); i++)
    {
      if (joueur.pos[1] >= tirs.get(i).pos[1] && joueur.pos[1] < tirs.get(i).pos[1]+tirs.get(i).size[1] && joueur.pos[0] > tirs.get(i).pos[0] && joueur.pos[0]+joueur.size[0] < tirs.get(i).pos[0]+tirs.get(i).size[0])
      {
        tirs.remove(i);
        joueur.degat();
        if (joueur.vie <= 0)
        {
          state = Scene.GameOver;
          joueur.resetPlayer();
        }
      }
    }
  }
  
  public boolean canBeHit(){
    return (millis() - timeSinceLastHit) > invicibilityTime;
  }
  
  public boolean canShoot(){
    return (millis() - timeSinceLastShot) > cooldownTime;
  }
}
class Calmar extends Boss
{
  Calmar(SoundMaster p_soundMaster)
  {
    super(p_soundMaster, "calmarBossDeath");
    
    for (int i = 0; i < 2; i++) 
    {
      boss[i] = loadImage("boss/calmar img"+i+".png");
    }
    deadBoss = loadImage("boss/calmar-dead.png");
    
    for (int i = 1; i <= 5; i++) 
    {
      attack[i-1] = loadImage("boss/jet_d_encre"+i+".png");
    }
    
    pos = append(pos, height/2);
    vie = 12;
  }
}
class Decor
{
  PImage[] filigranes = new PImage[10], fonds = new PImage[2];

  Decor()
  {
    fonds[0] = loadImage("décor/background.png");
    fonds[1] = loadImage("fond.png");
    for (int i = 1; i < 9; i++) filigranes[i-1] = loadImage("filigranes/texture00"+i+".png");
  }

  public void afficherFond()
  {
    image(fonds[state != Scene.Game ? 0 : 1], 0, 0);
  }
  public void afficherFiligranes()
  {
    image(filigranes[(frameCount/3)%8], 0, 0);
  }
}
class Ennemi extends NonPlayableObject
{
  int dureeDeVie;
  int[] pos = { width };
  int[] size = {150, 109};
  PImage[] ennemi = new PImage[2];
  SoundMaster soundMaster;
  
  Ennemi(SoundMaster p_soundMaster)
  {
    for (int i = 0; i < 2; i++) 
    {
      ennemi[i] = loadImage("poisson img"+i+".png");
    }
    
    pos = append(pos, PApplet.parseInt(random(height-90-98-10)));
    
    soundMaster = p_soundMaster;
  }
  
  public void deplacer()
  {
    pos[0] -= 5;
  }
  
  public void afficher()
  {
    dureeDeVie++;
    image(ennemi[(frameCount/5)%2],pos[0], pos[1], size[0], size[1]);
  }
  
  
  public boolean collision()
  {
    if(joueur.pos[0] < pos[0]+size[0] && joueur.pos[0]+joueur.size[0] > pos[0] && joueur.pos[1] < pos[1]+size[1] && joueur.pos[1]+joueur.size[1] > pos[1])   
    {
      joueur.degat();
      return true;
    }
    
    for (int i = 0; i < joueur.tirs.size(); i++)
    {
      if (joueur.tirs.get(i).pos[1] >= pos[1] && joueur.tirs.get(i).pos[1] < pos[1]+size[1] && joueur.tirs.get(i).pos[0] > pos[0] && joueur.tirs.get(i).pos[0]+20 < pos[0]+size[0])
      {
        soundMaster.playSoundEffect("ennemyDeath");
        joueur.tirs.remove(i);
        joueur.score++;
        return true;
      }
    }
    return false; 
  } 
}
class Joueur extends PlayableObject
{
  int[] pos = { 100, 360 };
  int[] size = {169, 169};

  PImage[] coeur = new PImage[8];
  PImage[][] joueur = new PImage[3][2];
  SoundMaster soundMaster;

  // Timer pour les frames d'invulnérabilité
  int timeSinceLastHit = 0;
  int invicibilityTime = 1000;

  Joueur(SoundMaster p_soundMaster)
  {
    for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 2; j++)
      {
        joueur[i][j] = loadImage("sous-marin img"+i+""+j+".png");
      }
    }
    for (int i = 1; i < 9; i++)
    {
      coeur[i-1] = loadImage("data/joueur/Health/frame-"+i+".png");
    }

    soundMaster = p_soundMaster;
    timeSinceLastHit = millis();
  }

  public void resetPlayer()
  {
    frequenceTirs = 0;
    vie = 3;
    degat = 0;
  }

  public void afficher()
  {
    for (int i = 0; i < vie; i++)
    {
      if (PApplet.parseInt(frameCount/4)%64 <= 8) image(coeur[PApplet.parseInt(frameCount/4)%coeur.length], i*48, 0, 48, 48);
      else image(coeur[0], i*48, 0, 48, 48);
    }
    textAlign(CENTER, CENTER);
    text(str(score)+"/"+ennemisGeneres, width/2, 24, 48);
    if (degat > 0)
    {
      tint(255, 0, 0);
      degat--;
    }
    if (degat < 0)
    {
      tint(0, 255, 0);
      degat++;
    }
    
    if (vie <= 0)
    {
      image(joueur[2][(frameCount/5)%2], pos[0], pos[1], size[0], size[1]);
      soundMaster.playSoundEffect("playerDeath");
    }
    else if (degat > 0)
    {
      image(joueur[1][(frameCount/5)%2], pos[0], pos[1], size[0], size[1]);
    }
    else
    {
      image(joueur[0][(frameCount/5)%2], pos[0], pos[1], size[0], size[1]);
    }

    tint(255, 255, 255);
    for (int i = 0; i < tirs.size(); i++)
    {
      if (tirs.get(i).pos[0] > width) tirs.remove(i);
    }
    for (Tir tir : tirs)
    {
      tir.afficherLaser();
    }
    tint(255, 255, 255);
  }

  public void degat()
  {
    if(canBeHit()){
      timeSinceLastHit = millis();
      vie --;
      degat = 15;
      soundMaster.playSoundEffect("playerHit");
    }
  }

  public void soin()
  {
    vie ++;
    degat = -15;
  }

  public void action(boolean[] touches)
  {
    if (touches[0] && pos[1] > 0) pos[1] -= 10 * speed; 
    if (touches[1] && pos[0] > 0) pos[0] -= 10 * speed; 
    if (touches[2] && pos[1] < height-size[1]) pos[1] += 10 * speed; 
    if (touches[3] && pos[0] < width-size[0]) pos[0] += 10 * speed; 
    if (touches[4])
    {
      if (frequenceTirs%12 == 0)
      {
        tirer();
      }
      frequenceTirs++;
    } else
    {
      frequenceTirs = 0;
    }


    for (Tir tir : tirs)
    {
      tir.deplacer();
      tir.afficherLaser();
    }
  }

  public void tirer()
  {
    tirs.add(new Tir(pos[0], pos[1]));
    soundMaster.playSoundEffect("baseLaserShot");
  }
  
  public boolean canBeHit(){
    return (millis() - timeSinceLastHit) > invicibilityTime;
  }
}
class Owen extends Boss
{
  Owen(SoundMaster p_soundMaster)
  {
    super(p_soundMaster, "owenBossDeath");
    
    for (int i = 0; i < 2; i++) 
    {
      boss[i] = loadImage("boss/owen img"+i+".png");
    }
    deadBoss = loadImage("boss/owen-dead.png");
    
    for (int i = 1; i <= 5; i++) 
    {
      attack[i-1] = loadImage("boss/os"+i+".png");
    }
        
    pos = append(pos, height/2);
    vie = 20;
  }
}
class SoundMaster {
Minim minim;

// MUSIQUES
Music introMusic;
Music musicLevel_1;
Music owenBattleMusic;

// SONS TIRS
SoundEffect baseLaserShot;

// SONS MISC
// ENNEMY
SoundEffect ennemyHit;
OneTimeSoundEffect calmarBossDeath;
OneTimeSoundEffect owenBossDeath;
OneTimeSoundEffect ennemyDeath;

// PLAYER
SoundEffect playerHit;
OneTimeSoundEffect playerDeath;

  SoundMaster(Minim p_minim){
    minim = p_minim;
    
    // MUSIQUE
    introMusic = new Music(minim, "intro", "/Sound/Music/Remastered/MenuIntroRM.mp3");
    musicLevel_1 = new Music(minim, "level1", "/Sound/Music/Remastered/VolumeAdjusted/Level1MusicRM.mp3");
    owenBattleMusic = new Music(minim, "owenBattleMusic", "/Sound/Music/Remastered/VolumeAdjusted/OwenBattleMusicRM.mp3");
    
    // TIRS
    baseLaserShot = new SoundEffect(minim, "baseLaserShot", "/Sound/Shoot/Remastered/VolumeAdjusted/BaseLaserShotRM.mp3");
    
    // MISC
    // ENNEMY
    ennemyHit = new SoundEffect(minim, "ennemyHit", "/Sound/Misc/Remastered/VolumeAdjusted/EnnemyHitRM.mp3");
    ennemyDeath = new OneTimeSoundEffect(minim, "ennemyDeath", "/Sound/Misc/Remastered/EnnemyDeathRM.mp3");
    calmarBossDeath = new OneTimeSoundEffect(minim, "bossDeath", "/Sound/Misc/Remastered/VolumeAdjusted/BossDeathRM.mp3");
    owenBossDeath = new OneTimeSoundEffect(minim, "bossDeath", "/Sound/Misc/Remastered/VolumeAdjusted/BossDeathRM.mp3");
    
    // PLAYER
    playerHit = new SoundEffect(minim, "playerHit", "/Sound/Misc/Remastered/PlayerHitRM.mp3");
    playerDeath = new OneTimeSoundEffect(minim, "playerDeath", "/Sound/Misc/Remastered/PlayerDeathRM.mp3");
    
  }

  public void playIntro(){
    stopLevelMusic();
    stopOwenMusic();
    introMusic.start();
  }
  
  public void stopIntro(){
    introMusic.stop();
  }
  
  public void playLevelMusic(){
    stopIntro();
    musicLevel_1.start();
  }
  
  public void stopLevelMusic(){
    musicLevel_1.stop();
  }
  
  public void playOwenMusic(){
    stopLevelMusic();
    owenBattleMusic.start();
  }
  
  public void stopOwenMusic(){
    owenBattleMusic.stop();
  }
  
  public void playSoundEffect(String effectName){
    switch(effectName){
      // SHOT
      case "baseLaserShot":
        baseLaserShot.start();
        break;
      
      // ENNEMY
      case "ennemyHit":
        ennemyHit.start();
        break;
      
      case "ennemyDeath":
        ennemyDeath.start();
        break;
      
      case "calmarBossDeath":
        calmarBossDeath.start();
        break;
        
      case "owenBossDeath":
        owenBossDeath.start();
        break;
        
      // PLAYER
      case "playerHit":
        playerHit.start();
        break;
      
      case "playerDeath":
        playerDeath.start();
        break;
    }
  }
}

class BaseSound{
  Minim minim;
  AudioPlayer player;
  
  String soundName = "";
  String soundPath = "";
  
  BaseSound(Minim p_minim, String p_soundName, String p_soundPath){
    minim = p_minim;
    
    soundName = p_soundName;
    soundPath = p_soundPath;
    
    player = minim.loadFile(soundPath);
  }
}

class Music extends BaseSound{
  Music(Minim p_minim, String p_musicName, String p_musicPath){
    super(p_minim, p_musicName, p_musicPath);
  }
  
  public void start(){
    if(!player.isPlaying()){
      player.loop();
    }
  }
  
  public void stop(){
    if(player.isPlaying()){
      player.pause();
      player.rewind();
    }
  }
  
}

class SoundEffect extends BaseSound {
  // A second player to avoid glitch when spamming the same sound ;)
  AudioPlayer player2;
  
  boolean usePlayer2 = false;
  
  SoundEffect(Minim p_minim, String p_effectName, String p_effectPath){
    super(p_minim, p_effectName, p_effectPath);
    player2 = minim.loadFile(p_effectPath);
  }
  
  public void startOneTimeEffect(){
  
  }
  
  public void start(){
    if(usePlayer2){
      startPlayer(player2);
      usePlayer2 = false;
    }
    else{
      startPlayer(player);
      usePlayer2 = true;
    }
  }
  
  public void startPlayer(AudioPlayer p_player){
    p_player.rewind();
    p_player.play();
  }
}

class OneTimeSoundEffect extends SoundEffect{
  boolean hasBeenPlayed = false;
  
  OneTimeSoundEffect(Minim p_minim, String p_effectName, String p_effectPath){
    super(p_minim, p_effectName, p_effectPath);
  }
  
  public void start(){
    if(!hasBeenPlayed){
      hasBeenPlayed = true;
      super.start();
    }
  }
}
  public void settings() {  size(1280, 720, P2D);  noSmooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "shootemup" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
